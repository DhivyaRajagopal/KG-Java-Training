
//String Joiner is a class used to separete the sequence of character.
//String Joiner is a constructor, so when we initialize an instance to StringJoiner class the delimiter is passed with default add() functions like predefined interface.

import java.util.StringJoiner;

public class StrJoin {
    public static void main(String... a) {
        StringJoiner sj = new StringJoiner(",","[","]");
        sj.add("DD");
        sj.add("Dhivya");
        sj.add("Manidha");
        sj.add("Aruna");
        System.out.println(sj);
    }
}
