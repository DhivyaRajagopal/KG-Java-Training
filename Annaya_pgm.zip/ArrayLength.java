public class ArrayLength {
	public static void main(String args[]) {
		int[] a = { 'a', 'b' };
		int b = a.length;
		System.out.println(b);
	}
}