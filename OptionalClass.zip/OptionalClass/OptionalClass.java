//Optional class is used to handle the  `Null pointer Exception.
//It having a default methods it selt called ifNullable() and isPresent().

 
import java.util.Optional;
public class OptionalClass
{
    public static void main(String...a){
        String str[]={"DHI","ARU","DD","KARADI","MANIDHA"};
        Optional<String> find=Optional.ofNullable(str[3]);
        if(find.isPresent()){
           
            System.out.println( str[0].toLowerCase());

        }else
        System.out.println("out of size string is not present");
    }
}