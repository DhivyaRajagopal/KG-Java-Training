
//Nashorn is a Java Script Engine used to embedded  java script into java.
//eval() is used to evaluate the java script String.


import javax.script.*; 
public class Engine{
    public static void main(String...a) throws Exception{  
ScriptEngine se = new ScriptEngineManager().getEngineByName("Nashorn");
se.eval("print('Got Noshorn Engine for JS');");

    }
}