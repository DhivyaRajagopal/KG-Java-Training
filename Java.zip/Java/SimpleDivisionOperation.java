public class SimpleDivisionOperation {
public static void main(String...a)
{
      System.out.println("Exception handling");
      div();
}
static void div()throws ArithmeticException
{
      int a=5,c=0;
      int d=a/c;
      throw new ArithmeticException("Divided by Zero error");
}
}