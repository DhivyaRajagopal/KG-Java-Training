class Ntry
{ 
    public static void main(String...g){
             int a=0,b=10;
         try{
            try{
                int c=b/a;
            }catch(Exception e)
            {
                System.out.println("error");
            }
        
        try{
            int d[]=new int[5];
            d[5]=5;
        }catch(Exception d)
        {
            System.out.println("errorrrrrr");
        }
         }catch(Exception f) 
   
    {
        System.out.println("helo completed");
    }


    
}
}