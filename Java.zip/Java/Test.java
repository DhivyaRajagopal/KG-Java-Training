

interface C
{
    void run();
    void start();
   
}
class B implements C
{
    void run()
    {
     System.out.println("This is A");
}
}
class A extends B
{
    
    void start()
    {
        System.out.println("Hello");
    }
}
class Test
{
    public static void main(String[] args) 
    {
        C c=new A();
        c.run();
        c.start();
    }
}