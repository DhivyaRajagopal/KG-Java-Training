abstract class My {
    public void myMethod() {
        System.out.print("Abstract");
    }
}
class Poly extends My {
    public static void main(String a[]) {
        My m = new My()
        m.myMethod();
    }
}