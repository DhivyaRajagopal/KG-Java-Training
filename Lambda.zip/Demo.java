

interface Sample{

public String sam(String str);
}
public class Demo{
    public static void main(String[] args) {
        
        Sample s=str->{
            return "Hai Good morning"+str;
        };
            System.out.println(s.sam("Dhivya"));

    }
}