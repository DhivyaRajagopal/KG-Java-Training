interface Sample1{
    public int operation(int a,int b);
}
public class Shift{
    public static void main(String[] args) {
        Sample1 s=(a,b)->(a<<2);
System.out.println(s.operation(10,2));
        
    }
}