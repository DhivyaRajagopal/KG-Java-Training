//method reference for static method 
interface Sample2 {
    public void method();

}

public class Reference {
    public static void method1() {
        System.out.println("Hai friends");
    }
    public static void main(String[] args) {
   
    Sample2 s=Reference::method1;
    s.method();
    }
}