//Java 8 Functional Interface

//Here I declare 2 classes for future extends

import java.util.function.BiFunction;
class Instance
{
    public static int operation(int a,int b)
    {
      return a<<b;
    }
}

public class PredefinedInterface{
    public static void main(String[] args) {
        BiFunction<Integer,Integer,Integer> bf=Instance::operation;
        int ans=bf.apply(10, 2);
        System.out.println(ans);
    }
}