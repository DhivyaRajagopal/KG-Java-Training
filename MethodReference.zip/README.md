# JAVA 8 
***Lambda Expression***
```````
interface Sample{

public String sam(String str);
}
public class Demo{
    public static void main(String[] args) {
        
        Sample s=str->{
            return "Hai Good morning"+str;
        };
            System.out.println(s.sam("Dhivya"));

    }
}

````````````
***Passing Parameter To Lambda***
`````
interface Sample1{
    public int operation(int a,int b);
}
public class Shift{
    public static void main(String[] args) {
        Sample1 s=(a,b)->(a<<2);
System.out.println(s.operation(10,2));
        
        
    }
}
````````