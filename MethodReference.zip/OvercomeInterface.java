//In Reference(My previous Example) class we didn't implement the method which is declared in the interface.

//To over come that we use Predefined interfaces like(Runable).

public class OvercomeInterface{
    public static void operation()
    {
      System.out.println("*Dhivya Imporvig @  java 8*");
    }
    public static void main(String[] args) {
     Thread t=new Thread(OvercomeInterface::operation); //Java 7 Functional interface
     t.start();
        
    }
} 