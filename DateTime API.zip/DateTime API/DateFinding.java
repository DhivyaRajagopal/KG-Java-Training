//Calculate Dates by using default packages minusDays(1) is a method.
// we should create a object for a class called LocalDate then only we can do further process.



import java.time.LocalDate;

public class DateFinding{
    public static void main(String...a){
System.out.println("Date finding API");
      
      LocalDate ld=LocalDate.now();
      System.out.println(ld);
       System.out.println(ld.minusDays(1));
        System.out.println(ld.plusDays(1));
          
    }
}
