//While using `default` keyword to a method in inetrface that should be implemented in one class . 


interface Demo {
    default void sample(int a, int b) {
        System.out.println("Dhivya finding default methods in java 8");
        System.out.println(a << b);

    }
}

public class DefaultMethods implements Demo {
    public static void main(String... a) {
        DefaultMethods dc = new DefaultMethods();
        dc.sample(10, 2);
    }
}